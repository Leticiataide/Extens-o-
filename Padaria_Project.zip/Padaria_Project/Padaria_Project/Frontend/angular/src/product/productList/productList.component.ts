import { Component, ViewChild, Inject } from '@angular/core';
import { MatDialog, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatTableDataSource } from '@angular/material/table';
import { PaginationType } from 'src/api/models/pagination';
import { Product } from 'src/api/models/product';
import { ProductService } from 'src/api/services/product.services';
import { convertAmericanFromBrazil } from 'src/common/util/formatNumber';

@Component({
  selector: 'productList-root',
  templateUrl: './productList.component.html',
  styleUrls: ['./productList.component.css'],
})
export class ProductListComponent {
  displayedColumns: string[] = ['id', 'name', 'priceSale', 'unity', 'action'];
  productList: Product[] = [];
  pagination: PaginationType = {
    length: 0,
    size: 0,
    lastPage: 0,
    page: 0,
    startIndex: 0,
    endIndex: 0,
  };
  dataSource: MatTableDataSource<Product>;

  page = 0;
  size = 25;
  search = '';
  order = 'asc';
  sort = 'id';

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;

  constructor(
    private productService: ProductService,
    private dialog: MatDialog,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit() {
    this.paginator._intl.itemsPerPageLabel = 'Itens por página:';
    this.paginator._intl.nextPageLabel = 'Próxima';
    this.paginator._intl.previousPageLabel = 'Anterior';
    this.paginator._intl.firstPageLabel = 'Primeira página';
    this.paginator._intl.lastPageLabel = 'Última página';
    this.paginator._intl.getRangeLabel = this.getDisplayText;

    this.productService.getProductPage().subscribe({
      next: (resp) => {
        this.productList = resp.results;
        this.pagination = resp.pagination;
        this.dataSourceValue();
      },
      error: (error) => {
        if (error.error.message) {
          this.snackBar.open(`${error.error.message}`, 'Error', {
            duration: 3000,
          });
        } else {
          this.snackBar.open(`Ocorreu um erro inesperado.`, 'Error', {
            duration: 3000,
          });
        }
      },
    });
  }

  convertBrazil(priceSale) {
    return `R$ ${convertAmericanFromBrazil(priceSale)}`;
  }

  getDisplayText(page: number, pageSize: number, length: number) {
    if (length == 0 || pageSize == 0) {
      return 'Sem resultados.';
    }
    const startIndex = page * pageSize;
    const endIndex =
      startIndex < length
        ? Math.min(startIndex + pageSize, length)
        : startIndex + pageSize;
    return `Itens: ${startIndex + 1} - ${endIndex} Página: ${
      page + 1
    } de ${Math.ceil(length / pageSize)}, total:${length} itens`;
  }

  dataSourceValue() {
    this.dataSource = new MatTableDataSource<Product>(this.productList);
  }

  handlePageEvent(event: any) {
    this.productService
      .getProductPage(
        event.pageIndex,
        this.size,
        this.search,
        this.order,
        this.sort
      )
      .subscribe({
        next: (resp) => {
          this.productList = resp.results;
          this.pagination = resp.pagination;
          this.dataSourceValue();
        },
        error: (error) => {
          if (error.error.message) {
            this.snackBar.open(`${error.error.message}`, 'Error', {
              duration: 3000,
            });
          } else {
            this.snackBar.open(`Ocorreu um erro inesperado.`, 'Error', {
              duration: 3000,
            });
          }
        },
      });
  }

  onChangeInput(e: any) {
    this.search = e.target.value;

    this.productService
      .getProductPage(0, this.size, this.search, this.order, this.sort)
      .subscribe({
        next: (resp) => {
          this.productList = resp.results;
          this.pagination = resp.pagination;
          this.dataSourceValue();
        },
        error: (error) => {
          if (error.error.message) {
            this.snackBar.open(`${error.error.message}`, 'Error', {
              duration: 3000,
            });
          } else {
            this.snackBar.open(`Ocorreu um erro inesperado.`, 'Error', {
              duration: 3000,
            });
          }
        },
      });
  }

  openDialog(e) {
    console.log(e);

    const dialog = this.dialog.open(DialogRemove, {
      data: { id: e.id, name: e.name },
    });
    dialog.afterClosed().subscribe((remove) => {
      if (remove) {
        this.removeProduct(e.id);
      }
    });
  }

  removeProduct(productId) {
    this.productService.remove(productId).subscribe({
      next: (_) => {
        this.productList = this.productList.filter(
          (item) => item.id != productId
        );
        this.pagination.length = this.pagination.length - 1;
        this.dataSourceValue();
        this.snackBar.open('Removido com sucesso.', 'Sucesso', {
          duration: 3000,
        });
      },
      error: (error) => {
        if (error.error.message) {
          this.snackBar.open(error.error.message, 'Error', {
            duration: 50000,
          });
        } else {
          this.snackBar.open('Ocorreu um erro inesperado.', 'Error', {
            duration: 3000,
          });
        }
      },
    });
  }
}

@Component({
  selector: 'dialog-remove',
  template: ` <div class="dialog-container">
    <div class="dialog-container-title">
      <h1 mat-dialog-title class="dialog-title">Remover produto</h1>
    </div>
    <div mat-dialog-content class="dialog-message">
      Gostaria de remover produto de nome: {{ data.name }} com id:
      {{ data.id }}?
    </div>
    <div mat-dialog-actions>
      <button mat-button [mat-dialog-close]="false">Cancelar</button>
      <button mat-button [mat-dialog-close]="true" cdkFocusInitial color="warn">
        Remover
      </button>
    </div>
  </div>`,
  styleUrls: ['./productList.component.css'],
})
export class DialogRemove {
  constructor(@Inject(MAT_DIALOG_DATA) public data: Product) {}
}
