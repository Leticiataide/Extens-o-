import styled, { css } from "styled-components";

export const Wrapper = styled.div`
  ${() => css``}
`;

export const Container = styled.div`
  ${() => css``}
`;
