import { ProductRegistrationTp } from "templates/product/registration";

export default function ProductRegistrationPage() {
  return <ProductRegistrationTp />;
}
