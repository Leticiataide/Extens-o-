import { ProductListTp } from "templates/product/list";

export default function ProductListPage() {
  return <ProductListTp />;
}
