export type Unity = {
  id?: number | null;
  name: string;
};
